import wx
import threading
import json
import time
import sys
import argparse

import socket
import asyncio
try:
    import websockets
except ImportError:
    websockets = None
import accessible_output2.outputs.auto

parser = argparse.ArgumentParser(description='Chatyour Client')
parser.add_argument('--host', default='10.211.55.5', help='Server hostname or IP')
parser.add_argument('--port', type=int, default=10000, help='Server port')
parser.add_argument("--ws", action="store_true", help="Force WebSocket mode")
args = parser.parse_args()

class ChatClientApp(wx.Frame):

    def __init__(self, title):
        super(ChatClientApp, self).__init__(None, title=title, size=(550, 750))
        
        try:
            self.speech = accessible_output2.outputs.auto.Auto()
        except:
            self.speech = None

        # State Variables
        self.client_socket = None
        self._ws = None
        self._ws_loop = None
        self._ws_ready = threading.Event()
        self.use_ws = args.ws or ("." in args.host and not args.host.replace(".", "").isdigit())
        self.current_room = None
        self.username = None
        self.is_admin = False
        
        # Network Drop Handlers - FIXED: Use localhost for testing local server connection
        self.server_host = args.host
        # CHANGED: Match the new unreserved port configured on the server
        self.server_port = args.port
        self.is_reconnecting = False
        self.keep_reconnect_threads_alive = True
        
        self.panel = wx.Panel(self)
        self.main_sizer = wx.BoxSizer(wx.VERTICAL)
        
        # Build System Windows
        self.create_auth_view()
        self.create_admin_setup_view()
        self.create_dashboard_view()
        self.create_chat_view()
        
        # Permanent Connection Event History Log (Shown in Main Menu Dashboard & Chats)
        log_label = wx.StaticText(self.panel, label="System Connection History Log Events:")
        self.global_log_history = wx.TextCtrl(self.panel, style=wx.TE_MULTILINE | wx.TE_READONLY, size=(-1, 120))
        
        self.main_sizer.Add(log_label, 0, wx.ALL | wx.EXPAND, 5)
        self.main_sizer.Add(self.global_log_history, 0, wx.ALL | wx.EXPAND, 5)
        
        self.show_view("auth")
        self.panel.SetSizer(self.main_sizer)
        self.Centre()
        
        self.setup_hotkeys()
        self.Bind(wx.EVT_CLOSE, self.on_close)

    def speak(self, text):
        if self.speech:
            try:
                self.speech.speak(text, interrupt=False)
            except:
                pass

    def show_view(self, view_name):
        self.auth_sizer.ShowItems(view_name == "auth")
        self.admin_setup_sizer.ShowItems(view_name == "admin_setup")
        self.dashboard_sizer.ShowItems(view_name == "dashboard")
        self.chat_sizer.ShowItems(view_name == "chat")
        
        if view_name == "dashboard" and self.is_admin:
            self.admin_box_sizer.ShowItems(True)
        else:
            self.admin_box_sizer.ShowItems(False)
            
        self.main_sizer.Layout()

    # --- View Initializers ---

    def create_auth_view(self):
        self.auth_sizer = wx.BoxSizer(wx.VERTICAL)
        
        # Non-affiliation Disclaimer Announcement Section
        disclaimer_text = (
            "NOTICE: This application is completely independent and is not in any way "
            "affiliated with, endorsed by, or copying any other software products or communication frameworks. "
            "Our focus is entirely on providing an accessible, functioning alternative client environment."
        )
        disclaimer_box = wx.StaticText(self.panel, label=disclaimer_text, style=wx.ALIGN_LEFT)
        disclaimer_box.Wrap(500)
        
        u_label = wx.StaticText(self.panel, label="Username:")
        self.u_input = wx.TextCtrl(self.panel, style=wx.TE_PROCESS_ENTER)
        p_label = wx.StaticText(self.panel, label="Password:")
        self.p_input = wx.TextCtrl(self.panel, style=wx.TE_PASSWORD)
        
        self.login_btn = wx.Button(self.panel, label="Login")
        self.register_btn = wx.Button(self.panel, label="Register An Account")
        
        self.auth_sizer.Add(disclaimer_box, 0, wx.ALL | wx.EXPAND, 8)
        self.auth_sizer.Add(wx.StaticLine(self.panel), 0, wx.EXPAND | wx.TOP | wx.BOTTOM, 5)
        self.auth_sizer.Add(u_label, 0, wx.ALL, 5)
        self.auth_sizer.Add(self.u_input, 0, wx.EXPAND | wx.ALL, 5)
        self.auth_sizer.Add(p_label, 0, wx.ALL, 5)
        self.auth_sizer.Add(self.p_input, 0, wx.EXPAND | wx.ALL, 5)
        self.auth_sizer.Add(self.login_btn, 0, wx.ALL, 5)
        self.auth_sizer.Add(self.register_btn, 0, wx.ALL, 5)
        
        self.login_btn.Bind(wx.EVT_BUTTON, self.on_login)
        self.register_btn.Bind(wx.EVT_BUTTON, self.on_register)
        self.main_sizer.Add(self.auth_sizer, 1, wx.EXPAND | wx.ALL, 10)

    def create_admin_setup_view(self):
        self.admin_setup_sizer = wx.BoxSizer(wx.VERTICAL)
        header = wx.StaticText(self.panel, label="Master Admin Key Confirmed. Register Permanent Identity:")
        
        adm_u_label = wx.StaticText(self.panel, label="Permanent Admin Username:")
        self.adm_u_input = wx.TextCtrl(self.panel)
        adm_p_label = wx.StaticText(self.panel, label="Permanent Admin Password:")
        self.adm_p_input = wx.TextCtrl(self.panel, style=wx.TE_PASSWORD)
        
        self.adm_submit_btn = wx.Button(self.panel, label="Save Admin Profile & Login")
        self.adm_submit_btn.Bind(wx.EVT_BUTTON, self.on_submit_admin_registration)
        
        self.admin_setup_sizer.Add(header, 0, wx.ALL, 5)
        self.admin_setup_sizer.Add(adm_u_label, 0, wx.ALL, 5)
        self.admin_setup_sizer.Add(self.adm_u_input, 0, wx.EXPAND | wx.ALL, 5)
        self.admin_setup_sizer.Add(adm_p_label, 0, wx.ALL, 5)
        self.admin_setup_sizer.Add(self.adm_p_input, 0, wx.EXPAND | wx.ALL, 5)
        self.admin_setup_sizer.Add(self.adm_submit_btn, 0, wx.ALL, 5)
        self.main_sizer.Add(self.admin_setup_sizer, 1, wx.EXPAND | wx.ALL, 10)

    def create_dashboard_view(self):
        self.dashboard_sizer = wx.BoxSizer(wx.VERTICAL)
        
        online_label = wx.StaticText(self.panel, label="Online Users:")
        self.online_listbox = wx.ListBox(self.panel)
        
        rooms_label = wx.StaticText(self.panel, label="Live Active Chat Rooms:")
        self.rooms_listbox = wx.ListBox(self.panel)
        
        saved_rooms_label = wx.StaticText(self.panel, label="Saved Database Backups available to Restore:")
        self.saved_rooms_listbox = wx.ListBox(self.panel)
        
        self.join_room_btn = wx.Button(self.panel, label="Join Selected Chat Room")
        self.create_room_btn = wx.Button(self.panel, label="Create New Chat Room")
        self.restore_room_btn = wx.Button(self.panel, label="Restore Selected Room Backup")
        
        self.join_room_btn.Bind(wx.EVT_BUTTON, self.on_join_room)
        self.create_room_btn.Bind(wx.EVT_BUTTON, self.on_create_room_dialog)
        self.restore_room_btn.Bind(wx.EVT_BUTTON, self.on_restore_saved_room)
        
        self.dashboard_sizer.Add(online_label, 0, wx.ALL, 5)
        self.dashboard_sizer.Add(self.online_listbox, 1, wx.EXPAND | wx.ALL, 5)
        self.dashboard_sizer.Add(rooms_label, 0, wx.ALL, 5)
        self.dashboard_sizer.Add(self.rooms_listbox, 1, wx.EXPAND | wx.ALL, 5)
        self.dashboard_sizer.Add(saved_rooms_label, 0, wx.ALL, 5)
        self.dashboard_sizer.Add(self.saved_rooms_listbox, 1, wx.EXPAND | wx.ALL, 5)
        
        self.dashboard_sizer.Add(self.join_room_btn, 0, wx.ALL, 5)
        self.dashboard_sizer.Add(self.create_room_btn, 0, wx.ALL, 5)
        self.dashboard_sizer.Add(self.restore_room_btn, 0, wx.ALL, 5)
        
        # Administrative Tools Panel
        self.admin_box_sizer = wx.StaticBoxSizer(wx.VERTICAL, self.panel, "Admin Console Controls")
        self.admin_motd_btn = wx.Button(self.panel, label="Admin: Configure Message of the Day (MOTD)")
        self.admin_delete_room_btn = wx.Button(self.panel, label="Admin: Force Delete Selected Room")
        self.admin_ban_user_btn = wx.Button(self.panel, label="Admin: Ban Selected User")
        self.admin_promote_user_btn = wx.Button(self.panel, label="Admin: Promote Selected User")
        self.admin_demote_user_btn = wx.Button(self.panel, label="Admin: Demote Selected User")
        self.admin_alert_btn = wx.Button(self.panel, label="Admin: Send Restart Warning Broadcast Alert")
        
        self.admin_motd_btn.Bind(wx.EVT_BUTTON, self.on_admin_set_motd_dialog)
        self.admin_delete_room_btn.Bind(wx.EVT_BUTTON, self.on_admin_delete_room)
        self.admin_ban_user_btn.Bind(wx.EVT_BUTTON, self.on_admin_ban_user)
        self.admin_promote_user_btn.Bind(wx.EVT_BUTTON, self.on_admin_promote_user)
        self.admin_demote_user_btn.Bind(wx.EVT_BUTTON, self.on_admin_demote_user)
        self.admin_alert_btn.Bind(wx.EVT_BUTTON, self.on_admin_send_restart_alert)
        
        self.admin_box_sizer.Add(self.admin_motd_btn, 0, wx.EXPAND | wx.ALL, 2)
        self.admin_box_sizer.Add(self.admin_delete_room_btn, 0, wx.EXPAND | wx.ALL, 2)
        self.admin_box_sizer.Add(self.admin_ban_user_btn, 0, wx.EXPAND | wx.ALL, 2)
        self.admin_box_sizer.Add(self.admin_promote_user_btn, 0, wx.EXPAND | wx.ALL, 2)
        self.admin_box_sizer.Add(self.admin_demote_user_btn, 0, wx.EXPAND | wx.ALL, 2)
        self.admin_box_sizer.Add(self.admin_alert_btn, 0, wx.EXPAND | wx.ALL, 2)
        
        self.dashboard_sizer.Add(self.admin_box_sizer, 0, wx.EXPAND | wx.ALL, 5)
        self.main_sizer.Add(self.dashboard_sizer, 1, wx.EXPAND | wx.ALL, 10)

    def create_chat_view(self):
        self.chat_sizer = wx.BoxSizer(wx.VERTICAL)
        self.chat_history = wx.TextCtrl(self.panel, style=wx.TE_MULTILINE | wx.TE_READONLY)
        msg_label = wx.StaticText(self.panel, label="Type your message:")
        self.msg_input = wx.TextCtrl(self.panel, style=wx.TE_PROCESS_ENTER)
        self.send_btn = wx.Button(self.panel, label="Send Message")
        
        self.chat_sizer.Add(self.chat_history, 1, wx.EXPAND | wx.ALL, 5)
        self.chat_sizer.Add(msg_label, 0, wx.ALL, 5)
        self.chat_sizer.Add(self.msg_input, 0, wx.EXPAND | wx.ALL, 5)
        self.chat_sizer.Add(self.send_btn, 0, wx.ALL, 5)
        
        self.msg_input.Bind(wx.EVT_TEXT_ENTER, self.on_send_message)
        self.send_btn.Bind(wx.EVT_BUTTON, self.on_send_message)
        self.main_sizer.Add(self.chat_sizer, 1, wx.EXPAND | wx.ALL, 10)

    def setup_hotkeys(self):
        ctrl_q_id = wx.NewIdRef()
        ctrl_s_id = wx.NewIdRef()
        
        self.Bind(wx.EVT_MENU, self.on_request_leave_room, id=ctrl_q_id)
        self.Bind(wx.EVT_MENU, self.on_request_save_room, id=ctrl_s_id)
        
        accel_tbl = wx.AcceleratorTable([
            (wx.ACCEL_CTRL, ord('Q'), ctrl_q_id),
            (wx.ACCEL_CTRL, ord('S'), ctrl_s_id)
        ])
        self.SetAcceleratorTable(accel_tbl)

    # --- Connection Monitoring ---

    def connect_server(self):
        if self.use_ws:
            if websockets is None:
                print("Install websockets: pip install websockets")
                return False
            return self._ws_connect()
        try:
            self.client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.client_socket.settimeout(3.0)
            self.client_socket.connect((self.server_host, self.server_port))
            self.client_socket.settimeout(None)
            
            threading.Thread(target=self.receive_handler, daemon=True).start()
            return True
        except Exception as e:
            self.client_socket = None
            return False

    def _ws_connect(self):
        try:
            self._ws = None
            self._ws_ready.clear()
            self._ws_loop = asyncio.new_event_loop()
            threading.Thread(target=self._ws_receive_loop, daemon=True).start()
            ok = self._ws_ready.wait(timeout=10)
            return ok and self._ws is not None
        except:
            return False

    def _ws_receive_loop(self):
        asyncio.set_event_loop(self._ws_loop)
        async def run():
            uri = "wss://%s:443/" % self.server_host
            try:
                async with websockets.connect(uri) as ws:
                    self._ws = ws
                    self._ws_ready.set()
                    while self.keep_reconnect_threads_alive:
                        try:
                            data = await ws.recv()
                            if isinstance(data, bytes):
                                data = data.decode("utf-8")
                            msg = json.loads(data)
                            wx.CallAfter(self.process_server_message, msg)
                        except Exception:
                            wx.CallAfter(self.handle_disconnection)
                            break
            except Exception as e:
                self._ws_ready.set()
        try:
            self._ws_loop.run_until_complete(run())
        except:
            pass

    def receive_handler(self):
        while True:
            try:
                data = self.client_socket.recv(4096)
                if not data:
                    raise ConnectionResetError()
                msg = json.loads(data.decode('utf-8'))
                wx.CallAfter(self.process_server_message, msg)
            except:
                wx.CallAfter(self.handle_disconnection)
                break

    def handle_disconnection(self):
        if self.is_reconnecting or not self.keep_reconnect_threads_alive:
            return
        self.is_reconnecting = True
        self.current_room = None
        self.show_view("auth")
        self.global_log_history.AppendText("[SYSTEM ALERT] Disconnected from hosting environment.\n")
        self.speak("Disconnected from host server. Trying to reconnect automatically in the background.")
        threading.Thread(target=self.rereconnect_worker, daemon=True).start()

    def rereconnect_worker(self):
        while self.keep_reconnect_threads_alive:
            if self.connect_server():
                self.is_reconnecting = False
                wx.CallAfter(self.on_reconnect_success)
                return
            time.sleep(4)

    def is_connected(self):
        return self.client_socket is not None or self._ws is not None

    def on_reconnect_success(self):
        self.global_log_history.AppendText("[SYSTEM ALERT] Socket network pipeline reconnected safely.\n")
        self.speak("Reconnected successfully. Please log back into your persistent account profile.")

    def process_server_message(self, msg):
        msg_type = msg.get("type")
        
        if msg_type == "admin_setup_phase":
            self.show_view("admin_setup")
            self.speak("Disposable admin verification success. Please build your permanent username and password profiles now.")
            
        elif msg_type == "auth_response":
            if msg.get("success"):
                self.username = msg.get("username")
                self.is_admin = msg.get("is_admin", False)
                self.show_view("dashboard")
                role_text = "as Administrator" if self.is_admin else ""
                self.speak(f"Logged in successfully {role_text}. Welcome {self.username}.")
                self.global_log_history.AppendText(f"[AUTH] Successfully authorized entry for profile: {self.username}\n")
            else:
                wx.MessageBox(msg.get("message"), "Auth Error", wx.OK | wx.ICON_WARNING)
                
        elif msg_type == "sync":
            self.rooms_listbox.Set(msg.get("rooms", []))
            self.online_listbox.Set(msg.get("users", []))
            self.saved_rooms_listbox.Set(msg.get("saved_rooms", []))
            
        elif msg_type == "status":
            content_str = msg.get("content")
            self.global_log_history.AppendText(f"[EVENT] {content_str}\n")
            self.speak(content_str)
            
        elif msg_type == "motd_broadcast":
            motd_content = msg.get("content")
            self.global_log_history.AppendText(f"[MOTD] {motd_content}\n")
            self.speak(f"Message of the day: {motd_content}")

        elif msg_type == "room_joined":
            self.current_room = msg.get("room")
            self.chat_history.Clear()
            self.show_view("chat")
            self.speak(f"Joined room {self.current_room}")
            self.global_log_history.AppendText(f"[ROOM ACTIVITY] Moved focus context inside room: {self.current_room}\n")
            self.msg_input.SetFocus()
            
        elif msg_type == "room_left":
            self.current_room = None
            self.chat_history.Clear()
            self.show_view("dashboard")
            if msg.get("forced"):
                wx.MessageBox(msg.get("reason"), "Alert", wx.OK | wx.ICON_INFORMATION)
                self.global_log_history.AppendText(f"[FORCED LEAVE] {msg.get('reason')}\n")
                self.speak(msg.get("reason"))
            else:
                self.global_log_history.AppendText("[ROOM ACTIVITY] Exited chat focus back to dashboard frame view.\n")
                self.speak("Returned back to main menu dashboard.")
                
        elif msg_type == "room_saved_confirmation":
            self.speak(f"Room {msg.get('room')} saved successfully to server database.")
                
        elif msg_type == "announcement" or msg_type == "chat":
            if self.current_room == msg.get("room"):
                self.chat_history.AppendText(msg.get("content") + "\n")
                self.speak(msg.get("content"))
            if msg_type == "announcement":
                self.global_log_history.AppendText(f"[CHATROOM LOG] ({msg.get('room')}) {msg.get('content')}\n")
                
        elif msg_type == "banned_notification":
            wx.MessageBox("You have been banned from this server.", "Banned", wx.OK | wx.ICON_ERROR)
            
        elif msg_type == "role_changed":
            self.is_admin = msg.get("is_admin", False)
            role = "admin" if self.is_admin else "user"
            self.global_log_history.AppendText(f"[ROLE] Your role has been changed to {role}.\n")
            self.speak(f"Your role has been changed to {role}.")
            self.show_view("dashboard")

        elif msg_type == "error":
            wx.MessageBox(msg.get("message"), "Error", wx.OK | wx.ICON_ERROR)

    # --- Actions ---

    def on_login(self, event):
        u = self.u_input.GetValue().strip()
        p = self.p_input.GetValue().strip()
        if not u or not p:
            wx.MessageBox("Please fill in both fields.", "Error", wx.OK | wx.ICON_ERROR)
            return

        if self.is_connected() or self.connect_server():
            try:
                self.send_data(json.dumps({"type": "login", "username": u, "password": p}).encode('utf-8'))
            except:
                wx.MessageBox("Failed to communicate with server. Try again.", "Network Error", wx.OK | wx.ICON_ERROR)
        else:
            wx.MessageBox("Could not reach server. Verify it's active.", "Connection Failed", wx.OK | wx.ICON_ERROR)

    def on_register(self, event):
        u = self.u_input.GetValue().strip()
        p = self.p_input.GetValue().strip()
        if not u or not p:
            wx.MessageBox("Please fill in both fields.", "Error", wx.OK | wx.ICON_ERROR)
            return

        if self.is_connected() or self.connect_server():
            try:
                self.send_data(json.dumps({"type": "register", "username": u, "password": p}).encode('utf-8'))
            except:
                wx.MessageBox("Failed to communicate with server.", "Network Error", wx.OK | wx.ICON_ERROR)
        else:
            wx.MessageBox("Could not reach server. Verify it's active.", "Connection Failed", wx.OK | wx.ICON_ERROR)

    def on_submit_admin_registration(self, event):
        u = self.adm_u_input.GetValue().strip()
        p = self.adm_p_input.GetValue().strip()
        if u and p and self.is_connected():
            self.send_data(json.dumps({"type": "register_admin", "username": u, "password": p}).encode('utf-8'))

    def on_create_room_dialog(self, event):
        dlg = wx.TextEntryDialog(self, "Enter Chat Room Name:", "Create Room")
        if dlg.ShowModal() == wx.ID_OK:
            room_name = dlg.GetValue().strip()
            if room_name and self.is_connected():
                self.send_data(json.dumps({"type": "create_room", "room_name": room_name}).encode('utf-8'))
        dlg.Destroy()

    def on_join_room(self, event):
        selection = self.rooms_listbox.GetStringSelection()
        if selection and self.is_connected():
            self.send_data(json.dumps({"type": "join_room", "room_name": selection}).encode('utf-8'))

    def on_restore_saved_room(self, event):
        selection = self.saved_rooms_listbox.GetStringSelection()
        if selection and self.is_connected():
            self.send_data(json.dumps({"type": "restore_room", "room_name": selection}).encode('utf-8'))
        else:
            self.speak("No room selected from backup list.")

    def on_send_message(self, event):
        text = self.msg_input.GetValue().strip()
        if text and self.current_room and self.is_connected():
            self.send_data(json.dumps({"type": "message", "room": self.current_room, "content": text}).encode('utf-8'))
            self.msg_input.Clear()
            self.msg_input.SetFocus()

    def on_request_leave_room(self, event):
        if self.current_room and self.is_connected():
            dial = wx.MessageDialog(None, "Are you sure you want to leave this room?", "Confirm Leave", wx.YES_NO | wx.NO_DEFAULT | wx.ICON_QUESTION)
            if dial.ShowModal() == wx.ID_YES:
                self.send_data(json.dumps({"type": "leave_room", "room": self.current_room}).encode('utf-8'))
            dial.Destroy()

    def on_request_save_room(self, event):
        if self.current_room and self.is_connected():
            self.send_data(json.dumps({"type": "save_room", "room": self.current_room}).encode('utf-8'))

    # --- Admin Trigger Actions ---

    def on_admin_set_motd_dialog(self, event):
        if self.is_admin and self.is_connected():
            dlg = wx.TextEntryDialog(self, "Enter new global Message of the Day:", "Configure MOTD")
            if dlg.ShowModal() == wx.ID_OK:
                motd_content = dlg.GetValue().strip()
                self.send_data(json.dumps({"type": "admin_set_motd", "content": motd_content}).encode('utf-8'))
            dlg.Destroy()

    def on_admin_delete_room(self, event):
        selection = self.rooms_listbox.GetStringSelection()
        if selection and self.is_connected():
            self.send_data(json.dumps({"type": "admin_delete_room", "room_name": selection}).encode('utf-8'))

    def on_admin_ban_user(self, event):
        selection = self.online_listbox.GetStringSelection()
        if selection and self.is_connected():
            if selection == self.username:
                self.speak("You cannot ban yourself.")
                return
            self.send_data(json.dumps({"type": "admin_ban_user", "target_username": selection}).encode('utf-8'))

    def on_admin_promote_user(self, event):
        selection = self.online_listbox.GetStringSelection()
        if selection and self.is_connected():
            if selection == self.username:
                self.speak("You cannot promote yourself.")
                return
            self.send_data(json.dumps({"type": "admin_promote_user", "target_username": selection}).encode('utf-8'))

    def on_admin_demote_user(self, event):
        selection = self.online_listbox.GetStringSelection()
        if selection and self.is_connected():
            if selection == self.username:
                self.speak("You cannot demote yourself.")
                return
            self.send_data(json.dumps({"type": "admin_demote_user", "target_username": selection}).encode('utf-8'))

    def on_admin_send_restart_alert(self, event):
        if self.is_admin and self.is_connected():
            self.send_data(json.dumps({"type": "admin_restart_alert"}).encode('utf-8'))

    def send_data(self, data):
        if self._ws is not None and self._ws_loop and self._ws_loop.is_running():
            asyncio.run_coroutine_threadsafe(self._ws.send(data), self._ws_loop)
        elif self.client_socket:
            self.client_socket.send(data)

    def on_close(self, event):
        self.keep_reconnect_threads_alive = False
        if self._ws is not None:
            try:
                if self._ws_loop and self._ws_loop.is_running():
                    asyncio.run_coroutine_threadsafe(self._ws.close(), self._ws_loop)
                    self._ws_loop.call_soon_threadsafe(self._ws_loop.stop)
            except:
                pass
        if self.client_socket:
            try:
                self.client_socket.close()
            except:
                pass
        self.Destroy()

if __name__ == "__main__":
    app = wx.App()
    frame = ChatClientApp("Chatyour Client")
    frame.Show()
    app.MainLoop()